import wordService from './word';
import posService from './pos';

export { wordService, posService };
