export enum POSEnum {
  noun = 'noun',
  verb = 'verb',
  adjective = 'adjective',
  pronoun = 'pronoun',
}
